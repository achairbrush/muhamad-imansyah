const express = require('express');
const { login, protectedRoute } = require('../controllers/authController');
const authenticateToken = require('../middlewares/authMiddleware');

const router = express.Router();

// Rute login
router.post('/login', login);


router.get('/protected', authenticateToken, protectedRoute);

module.exports = router;
