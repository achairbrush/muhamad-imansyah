const mysql = require('mysql');

// Konfigurasi koneksi database
const db = mysql.createConnection({
    host: 'localhost', 
    user: 'root',     
    password: '',     
    database: 'jwt_tugas'
});


db.connect((err) => {
    if (err) {
        console.error('Gagal terhubung ke database:', err.message);
        return;
    }
    console.log('Terhubung ke database MySQL.');
});

module.exports = db;
