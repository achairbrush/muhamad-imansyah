const express = require('express');
const User = require('../models/user');
const router = express.Router();

// Halaman Registrasi
router.get('/registrasi', (req, res) => {
    res.render('registrasi', { message: req.flash('error') });
});

// Proses Registrasi
router.post('/registrasi', async (req, res) => {
    const { username, password } = req.body;
    try {
        const newUser  = new User({ username, password });
        await newUser .save();
        req.flash('success', 'Registrasi berhasil! Silakan login.');
        res.redirect('/login');
    } catch (error) {
        req.flash('error', 'Username sudah terdaftar.');
        res.redirect('/registrasi');
    }
});

// Halaman Login
router.get('/login', (req, res) => {
    res.render('login', { message: req.flash('error') });
});

// Proses Login
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (user && await user.comparePassword(password)) {
        req.session.userId = user._id;
        res.redirect('/dashboard');
    } else {
        req.flash('error', 'Username atau password salah.');
        res.redirect('/login');
    }
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

module.exports = router;