const express = require('express');
const Fisherman = require('../models/fisherman');
const router = express.Router();

// Halaman untuk menampilkan semua nelayan
router.get('/', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    const fishermen = await Fisherman.find();
    res.render('fishermen', { fishermen });
});

// Halaman untuk menambahkan nelayan
router.get('/add', (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    res.render('addFisherman');
});

// Proses menambahkan nelayan
router.post('/add', async (req, res) => {
    const { name, catch: catchAmount } = req.body;
    const newFisherman = new Fisherman({ name, catch: catchAmount });
    await newFisherman.save();
    res.redirect('/fishermen');
});

// Halaman untuk mengedit nelayan
router.get('/edit/:id', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    const fisherman = await Fisherman.findById(req.params.id);
    res.render('editFisherman', { fisherman });
});

// Proses mengedit nelayan
router.post('/edit/:id', async (req, res) => {
    const { name, catch: catchAmount } = req.body;
    await Fisherman.findByIdAndUpdate(req.params.id, { name, catch: catchAmount });
    res.redirect('/fishermen');
});

// Proses menghapus nelayan
router.get('/delete/:id', async (req, res) => {
    await Fisherman.findByIdAndDelete(req.params.id);
    res.redirect('/fishermen');
});

module.exports = router;