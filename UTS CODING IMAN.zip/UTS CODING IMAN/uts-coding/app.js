const express = require('express');
const mongoose = require('mongoose');
const mysql = require('mysql2');
const session = require('express-session');
const bodyParser = require('body-parser');
const flash = require('connect-flash');
const path = require('path');

// Rute
const authRoutes = require('./routes/auth');
const fishermenRoutes = require('./routes/fisherman');

const app = express();
const PORT = process.env.PORT || 3000;

// Koneksi ke MySQL
const mysqlConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Ganti dengan username MySQL Anda
    password: '', // Ganti dengan password MySQL Anda
    database: 'fishing_app'
});

mysqlConnection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL database.');
});

// Koneksi ke MongoDB
mongoose.connect('mongodb://localhost:27017/fishermanDB', { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
}).then(() => {
    console.log('Connected to MongoDB database.');
}).catch(err => {
    console.error('Error connecting to MongoDB:', err);
});

// Middleware
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'jdoddjwididjwijw',
    resave: false,
    saveUninitialized: true
}));
app.use(flash());

// Halaman Dashboard
app.get('/dashboard', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    // Menggunakan MongoDB untuk menghitung nelayan dan total catch
    const totalFishermen = await Fisherman.countDocuments();
    const totalCatch = await Fisherman.aggregate([{ $group: { _id: null, total: { $sum: "$catch" } } }]);
    const totalCatchAmount = totalCatch.length > 0 ? totalCatch[0].total : 0;

    res.render('dashboard', { 
        userId: req.session.userId,
        totalFishermen,
        totalCatchAmount
    });
});

// Rute untuk otentikasi dan nelayan
app.use('/', authRoutes);
app.use('/fisherman', fishermenRoutes);

// Jalankan server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});