const validateCustomer = (req, res, next) => {
    const { name, email, phone, address } = req.body;
    const errors = [];

    // Validate name
    if (!name || name.trim().length < 2) {
        errors.push('Name must be at least 2 characters long');
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
        errors.push('Please enter a valid email address');
    }

    // Validate phone
    const phoneRegex = /^\+?[\d\s-]{10,}$/;
    if (!phone || !phoneRegex.test(phone)) {
        errors.push('Please enter a valid phone number');
    }

    // Validate address
    if (!address || address.trim().length < 5) {
        errors.push('Address must be at least 5 characters long');
    }

    if (errors.length > 0) {
        return res.status(400).render('customers/create', {
            errors,
            customer: req.body
        });
    }

    next();
};

module.exports = {
    validateCustomer
};