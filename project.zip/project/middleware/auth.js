module.exports = {
    isAuthenticated: (req, res, next) => {
        if (req.session.user) {
            return next();
        }
        req.session.error = 'Please login to access this page';
        res.redirect('/auth/login');
    },

    isAdmin: (req, res, next) => {
        if (req.session.user && req.session.user.role === 'admin') {
            return next();
        }
        res.status(403).render('error', {
            message: 'Access Denied',
            error: { status: 403 },
            status: 403
        });
    }
};