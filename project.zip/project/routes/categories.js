const express = require('express');
const router = express.Router();
const db = require('../config/database');



router.get('/dashboard', async (req, res) => {
    try {
        const [productCount] = await db.query('SELECT COUNT(*) as count FROM products');
        const [transactionCount] = await db.query('SELECT COUNT(*) as count FROM transactions');
        const [categoryCount] = await db.query('SELECT COUNT(*) as count FROM categories');
        const [customerCount] = await db.query('SELECT COUNT(*) as count FROM customers');

        res.render('dashboard', {
            user: req.session.user,
            productCount: productCount[0].count,
            transactionCount: transactionCount[0].count,
            categoryCount: categoryCount[0].count,
            customerCount: customerCount[0].count
        });
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).send('Server Error');
    }
});


// Get all categories
router.get('/', async (req, res) => {
    try {
        const [categories] = await db.query('SELECT * FROM categories');
        res.render('categories/index', { categories });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show create form
router.get('/create', (req, res) => {
    res.render('categories/create');
});

// Create new category
router.post('/', async (req, res) => {
    try {
        const { name } = req.body;
        await db.query('INSERT INTO categories (name) VALUES (?)', [name]);
        res.redirect('/categories');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show edit form
router.get('/edit/:id', async (req, res) => {
    try {
        const [categories] = await db.query('SELECT * FROM categories WHERE id = ?', [req.params.id]);
        res.render('categories/edit', { category: categories[0] });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Update category
router.post('/edit/:id', async (req, res) => {
    try {
        const { name } = req.body;
        await db.query('UPDATE categories SET name = ? WHERE id = ?', [name, req.params.id]);
        res.redirect('/categories');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Delete category
router.post('/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM categories WHERE id = ?', [req.params.id]);
        res.redirect('/categories');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

module.exports = router;