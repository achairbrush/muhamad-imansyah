const express = require('express');
const router = express.Router();
const db = require('../config/database');


// Create new category
router.post('/', async (req, res) => {
  try {
      const { name, description } = req.body;
      
      if (!name) {
          throw new Error('Name is required');
      }

      const [result] = await db.query(
          'INSERT INTO categories (name, description) VALUES (?, ?)', 
          [name, description || null]
      );

      console.log('Insert result:', result);
      res.redirect('/categories');
  } catch (error) {
      console.error('Error saving category:', error);
      res.status(500).send(`Error saving category: ${error.message}`);
  }
});
// Get all categories
router.get('/', async (req, res) => {
    try {
        const [categories] = await db.query('SELECT * FROM categories');
        res.render('categories/index', { categories });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show create form
router.get('/create', (req, res) => {
    res.render('categories/create');
});

// Create new category
router.post('/', async (req, res) => {
    try {
        const { name, description } = req.body;
        await db.query('INSERT INTO categories (name, description) VALUES (?, ?)', 
            [name, description]);
        res.redirect('/categories');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show edit form
router.get('/edit/:id', async (req, res) => {
    try {
        const [category] = await db.query('SELECT * FROM categories WHERE id = ?', 
            [req.params.id]);
        res.render('categories/edit', { category: category[0] });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Update category
router.post('/update/:id', async (req, res) => {
    try {
        const { name, description } = req.body;
        await db.query('UPDATE categories SET name = ?, description = ? WHERE id = ?',
            [name, description, req.params.id]);
        res.redirect('/categories');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Delete category
router.post('/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM categories WHERE id = ?', [req.params.id]);
        res.redirect('/categories');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

module.exports = router;