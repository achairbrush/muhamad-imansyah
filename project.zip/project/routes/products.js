const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all products
router.get('/', async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products');
        res.render('products/index', { products });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show create form
router.get('/create', (req, res) => {
    res.render('products/create');
});

// Create new product
router.post('/', async (req, res) => {
    try {
        const { name, description, price } = req.body;
        await db.query('INSERT INTO products (name, description, price) VALUES (?, ?, ?)', [name, description, price]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show edit form
router.get('/edit/:id', async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
        res.render('products/edit', { product: products[0] });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Update product
router.post('/edit/:id', async (req, res) => {
    try {
        const { name, description, price } = req.body;
        await db.query('UPDATE products SET name = ?, description = ?, price = ? WHERE id = ?', [name, description, price, req.params.id]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Delete product
router.post('/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Di dalam fungsi untuk menampilkan form create dan edit
router.get('/create', async (req, res) => {
    const [categories] = await db.query('SELECT * FROM categories');
    res.render('products/create', { categories });
});

router.get('/edit/:id', async (req, res) => {
    const [products] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    const [categories] = await db.query('SELECT * FROM categories');
    res.render('products/edit', { product: products[0], categories });
});

// Di dalam fungsi create dan update, tambahkan category_id
router.post('/', async (req, res) => {
    try {
        const { name, description, price, category_id } = req.body;
        await db.query('INSERT INTO products (name, description, price, category_id) VALUES (?, ?, ?, ?)', [name, description, price, category_id]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

router.post('/edit/:id', async (req, res) => {
    try {
        const { name, description, price, category_id } = req.body;
        await db.query('UPDATE products SET name = ?, description = ?, price = ?, category_id = ? WHERE id = ?', [name, description, price, category_id, req.params.id]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});


module.exports = router;