const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isAuthenticated } = require('../middleware/auth');

// Terapkan middleware isAuthenticated untuk semua route di bawah ini
router.use(isAuthenticated);

// Get all products
router.get('/', async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products');
        res.render('products/index', { products });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show create form
router.get('/create', (req, res) => {
    res.render('products/create');
});

// Create new product
router.post('/', async (req, res) => {
    try {
        const { name, price, stock } = req.body;
        await db.query('INSERT INTO products (name, price, stock) VALUES (?, ?, ?)', 
            [name, price, stock]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show edit form
router.get('/edit/:id', async (req, res) => {
    try {
        const [product] = await db.query('SELECT * FROM products WHERE id = ?', 
            [req.params.id]);
        res.render('products/edit', { product: product[0] });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Update product
router.post('/update/:id', async (req, res) => {
    try {
        const { name, price, stock } = req.body;
        await db.query('UPDATE products SET name = ?, price = ?, stock = ? WHERE id = ?',
            [name, price, stock, req.params.id]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Delete product
router.post('/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Get product by ID
router.get('/:id', async (req, res) => {
    try {
        const [product] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
        if (product.length > 0) {
            res.json(product[0]);
        } else {
            res.status(404).json({ message: 'Product not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
});

module.exports = router;