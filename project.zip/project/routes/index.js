// routes/index.js
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.render('landing');  // Pastikan tidak ada spasi setelah 'landing'
});

module.exports = router;