const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all transactions
router.get('/', async (req, res) => {
    try {
        const [transactions] = await db.query(`
            SELECT t.*, p.name AS product_name, c.name AS customer_name 
            FROM transactions t
            JOIN products p ON t.product_id = p.id
            JOIN customers c ON t.customer_id = c.id
            ORDER BY t.created_at DESC
        `);
        res.render('transactions/index', { transactions });
    } catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).render('error', { message: 'Error fetching transactions' });
    }
});

// Show create form
router.get('/create', async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products ORDER BY name');
        const [customers] = await db.query('SELECT * FROM customers ORDER BY name');
        res.render('transactions/create', { products, customers });
    } catch (error) {
        console.error('Error fetching data for create form:', error);
        res.status(500).render('error', { message: 'Error loading create form' });
    }
});

// Create new transaction
router.post('/', async (req, res) => {
    try {
        const { product_id, customer_id, quantity } = req.body;
        if (!product_id || !customer_id || !quantity) {
            return res.status(400).render('error', { message: 'All fields are required' });
        }

        // Validasi quantity
        if (isNaN(quantity) || quantity <= 0) {
            return res.status(400).render('error', { message: 'Quantity must be a positive number' });
        }

        await db.query(
            'INSERT INTO transactions (product_id, customer_id, quantity) VALUES (?, ?, ?)', 
            [product_id, customer_id, quantity]
        );
        res.redirect('/transactions');
    } catch (error) {
        console.error('Error creating transaction:', error);
        res.status(500).render('error', { message: 'Error creating transaction' });
    }
});

// Show edit form
router.get('/edit/:id', async (req, res) => {
    try {
        const [transactions] = await db.query('SELECT * FROM transactions WHERE id = ?', [req.params.id]);
        if (transactions.length === 0) {
            return res.status(404).render('error', { message: 'Transaction not found' });
        }
        const [products] = await db.query('SELECT * FROM products ORDER BY name');
        const [customers] = await db.query('SELECT * FROM customers ORDER BY name');
        res.render('transactions/edit', { transaction: transactions[0], products, customers });
    } catch (error) {
        console.error('Error fetching data for edit form:', error);
        res.status(500).render('error', { message: 'Error loading edit form' });
    }
});

// Update transaction
router.post('/edit/:id', async (req, res) => {
    try {
        const { product_id, customer_id, quantity } = req.body;
        if (!product_id || !customer_id || !quantity) {
            return res.status(400).render('error', { message: 'All fields are required' });
        }
        await db.query(
            'UPDATE transactions SET product_id = ?, customer_id = ?, quantity = ? WHERE id = ?', 
            [product_id, customer_id, quantity, req.params.id]
        );
        res.redirect('/transactions');
    } catch (error) {
        console.error('Error updating transaction:', error);
        res.status(500).render('error', { message: 'Error updating transaction' });
    }
});

// Delete transaction
router.post('/delete/:id', async (req, res) => {
    try {
        const [result] = await db.query('DELETE FROM transactions WHERE id = ?', [req.params.id]);
        if (result.affectedRows === 0) {
            return res.status(404).render('error', { message: 'Transaction not found' });
        }
        res.redirect('/transactions');
    } catch (error) {
        console.error('Error deleting transaction:', error);
        res.status(500).render('error', { message: 'Error deleting transaction' });
    }
});

module.exports = router;
