const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isAuthenticated } = require('../middleware/auth');

// Terapkan middleware isAuthenticated untuk semua route
router.use(isAuthenticated);

// Get all transactions (index)
router.get('/', async (req, res) => {
    try {
        const [transactions] = await db.query(`
            SELECT t.*, c.name as customer_name, p.name as product_name 
            FROM transactions t
            JOIN customers c ON t.customer_id = c.id
            JOIN products p ON t.product_id = p.id
            ORDER BY t.transaction_date DESC
        `);
        res.render('transactions/index', { transactions });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show create transaction form
router.get('/create', async (req, res) => {
    try {
        const [customers] = await db.query('SELECT * FROM customers');
        const [products] = await db.query('SELECT * FROM products');
        res.render('transactions/create', { customers, products });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Create new transaction
router.post('/', async (req, res) => {
    try {
        const { customer_id, product_id, quantity, total_amount } = req.body;
        
        await db.beginTransaction();

        // Check if product has enough stock
        const [product] = await db.query('SELECT stock FROM products WHERE id = ?', [product_id]);
        
        if (product[0].stock < quantity) {
            await db.rollback();
            return res.status(400).send('Not enough stock available');
        }

        // Insert transaction
        await db.query(
            'INSERT INTO transactions (customer_id, product_id, quantity, total_amount) VALUES (?, ?, ?, ?)',
            [customer_id, product_id, quantity, total_amount]
        );

        // Update product stock
        await db.query(
            'UPDATE products SET stock = stock - ? WHERE id = ?',
            [quantity, product_id]
        );

        await db.commit();
        res.redirect('/transactions');
    } catch (error) {
        await db.rollback();
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// View transaction details
router.get('/view/:id', async (req, res) => {
    try {
        const [transaction] = await db.query(`
            SELECT t.*, c.name as customer_name, p.name as product_name 
            FROM transactions t
            JOIN customers c ON t.customer_id = c.id
            JOIN products p ON t.product_id = p.id
            WHERE t.id = ?
        `, [req.params.id]);
        
        if (transaction.length === 0) {
            return res.status(404).send('Transaction not found');
        }
        
        res.render('transactions/view', { transaction: transaction[0] });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

module.exports = router;