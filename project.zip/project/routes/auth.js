const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require('../config/database');

// Login page
router.get('/login', (req, res) => {
  res.render('auth/login', { error: req.session.error });
});

// Login process
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [users] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    if (users.length > 0) {
      const match = await bcrypt.compare(password, users[0].password);
      if (match) {
        req.session.user = { id: users[0].id, username: users[0].username, role: users[0].role };
        res.redirect('/dashboard');
      } else {
        req.session.error = 'Invalid username or password';
        res.redirect('/auth/login');
      }
    } else {
      req.session.error = 'Invalid username or password';
      res.redirect('/auth/login');
    }
  } catch (error) {
    console.error(error);
    next(error); // Pass error to the error handler
  }
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
    }
    res.redirect('/auth/login');
  });
});

module.exports = router;