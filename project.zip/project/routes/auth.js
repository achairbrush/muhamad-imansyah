const express = require('express');
const router = express.Router();

// Data pengguna (untuk contoh, sebaiknya gunakan database)
const users = [
    { username: 'admin', password: 'admin123' },
    { username: 'user', password: 'user123' }
];

// Route untuk menampilkan halaman login
router.get('/login', (req, res) => {
    res.render('login', { error: null });
});

// Route untuk memproses login
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log('Login attempt:', { username, password }); // Debugging

    // Cari user
    const user = users.find(u => 
        u.username === username && 
        u.password === password
    );

    if (user) {
        // Set session
        req.session.user = {
            username: user.username
        };
        console.log('Login successful:', user.username); // Debugging
        return res.redirect('/dashboard');
    }

    console.log('Login failed'); // Debugging
    res.render('login', { 
        error: 'Username atau password salah!'
    });
});

// Route untuk logout
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/auth/login');
});

module.exports = router;