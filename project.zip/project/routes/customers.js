const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isAuthenticated } = require('../middleware/auth');
const { validateCustomer } = require('../middleware/validation');

// Apply authentication middleware to all routes
router.use(isAuthenticated);

// Get all customers
router.get('/', async (req, res) => {
    try {
        const [customers] = await db.query('SELECT * FROM customers');
        res.render('customers/index', { customers });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show create customer form
router.get('/create', (req, res) => {
    res.render('customers/create');
});

// Create customer
router.post('/', validateCustomer, async (req, res) => {
    try {
        const { name, email, phone, address } = req.body;
        
        // Check if email already exists
        const [existingCustomer] = await db.query('SELECT id FROM customers WHERE email = ?', [email]);
        if (existingCustomer.length > 0) {
            return res.status(400).render('customers/create', {
                error: 'Email already exists',
                customer: req.body
            });
        }

        await db.query(
            'INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)',
            [name, email, phone, address]
        );
        res.redirect('/customers');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Show edit customer form
router.get('/edit/:id', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM customers WHERE id = ?', [req.params.id]);
        if (rows.length > 0) {
            res.render('customers/edit', { customer: rows[0] });
        } else {
            res.status(404).send('Customer not found');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Update customer
router.post('/edit/:id', validateCustomer, async (req, res) => {
    try {
        const { name, email, phone, address } = req.body;
        
        // Check if email exists for other customers
        const [existingCustomer] = await db.query(
            'SELECT id FROM customers WHERE email = ? AND id != ?', 
            [email, req.params.id]
        );
        
        if (existingCustomer.length > 0) {
            return res.status(400).render('customers/edit', {
                error: 'Email already exists',
                customer: { ...req.body, id: req.params.id }
            });
        }

        await db.query(
            'UPDATE customers SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?',
            [name, email, phone, address, req.params.id]
        );
        res.redirect('/customers');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Delete customer
router.post('/delete/:id', async (req, res) => {
    try {
        // Check if customer has transactions
        const [transactions] = await db.query(
            'SELECT id FROM transactions WHERE customer_id = ?',
            [req.params.id]
        );

        if (transactions.length > 0) {
            return res.status(400).send('Cannot delete customer with existing transactions');
        }

        await db.query('DELETE FROM customers WHERE id = ?', [req.params.id]);
        res.redirect('/customers');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

module.exports = router;