const express = require('express');
const router = express.Router();
const db = require('../config/database'); // Pastikan ini sudah disetup

// Middleware untuk cek autentikasi
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// Daftar pelanggan
router.get('/', isAuthenticated, async (req, res) => {
    try {
        const [customers] = await db.query('SELECT * FROM customers');
        res.render('customers/index', { customers });
    } catch (error) {
        console.error('Error fetching customers:', error);
        res.status(500).send('Server Error');
    }
});

// Halaman tambah pelanggan
router.get('/add', isAuthenticated, (req, res) => {
    res.render('customers/add');
});

// Proses tambah pelanggan
router.post('/add', isAuthenticated, async (req, res) => {
    const { name, email } = req.body;
    try {
        await db.query('INSERT INTO customers (name, email) VALUES (?, ?)', [name, email]);
        res.redirect('/customers');
    } catch (error) {
        console.error('Error adding customer:', error);
        res.status(500).send('Server Error');
    }
});

// Halaman edit pelanggan
router.get('/edit/:id', isAuthenticated, async (req, res) => {
    try {
        const [customers] = await db.query('SELECT * FROM customers WHERE id = ?', [req.params.id]);
        if (customers.length === 0) {
            return res.status(404).send('Customer not found');
        }
        res.render('customers/edit', { customer: customers[0] });
    } catch (error) {
        console.error('Error fetching customer:', error);
        res.status(500).send('Server Error');
    }
});

// Proses edit pelanggan
router.post('/edit/:id', isAuthenticated, async (req, res) => {
    const { name, email } = req.body;
    try {
        await db.query('UPDATE customers SET name = ?, email = ? WHERE id = ?', [name, email, req.params.id]);
        res.redirect('/customers');
    } catch (error) {
        console.error('Error updating customer:', error);
        res.status(500).send('Server Error');
    }
});

module.exports = router;