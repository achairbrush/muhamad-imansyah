// controllers/authController.js
const users = [
    { username: 'admin', password: 'admin' }, // Contoh pengguna, ganti dengan database nyata
];

function authenticateUser (username, password, callback) {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        callback(null, user);
    } else {
        callback(new Error('Invalid credentials'), null);
    }
}

module.exports = { authenticateUser  };