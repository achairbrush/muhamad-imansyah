require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const app = express();
const fs = require('fs');

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000 
    }
}));

// Routes
app.use('/auth', require('./routes/auth'));

// Home route
app.get('/', (req, res) => {
    res.render('index', { 
        user: req.session.user,
        title: 'Home'
    });
});

// 404 handler
app.use((req, res, next) => {
    res.status(404).render('error', {
        title: 'Error',
        status: 404,
        message: 'Page Not Found',
        error: {}
    });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', {
    status: 500,
    message: 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

// Log error ke file
fs.appendFileSync('error.log', `${new Date().toISOString()} - ${err.stack}\n`);

res.status(500).render('error', {
  status: 500,
  message: 'Internal Server Error',
  error: process.env.NODE_ENV === 'development' ? err : {}
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

module.exports = app;