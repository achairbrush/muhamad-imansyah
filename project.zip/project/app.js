const express = require('express');
const session = require('express-session');
const path = require('path');
const app = express();
const db = require('./config/database'); // Pastikan file ini ada dan terkonfigurasi dengan benar

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware penting
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: process.env.NODE_ENV === 'production', // set true jika menggunakan HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 jam
    }
}));

// Middleware untuk cek autentikasi
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// Routes
app.use('/auth', require('./routes/auth'));
app.use('/products', isAuthenticated, require('./routes/products'));
app.use('/customers', isAuthenticated, require('./routes/customers'));
app.use('/categories', isAuthenticated, require('./routes/categories'));
app.use('/transactions', isAuthenticated, require('./routes/transactions'));

// Dashboard route (protected)
app.get('/dashboard', isAuthenticated, async (req, res) => {
    try {
        const [categories] = await db.query('SELECT * FROM categories');
        const [customerCount] = await db.query('SELECT COUNT(*) as count FROM customers');
        const [productCount] = await db.query('SELECT COUNT(*) as count FROM products');
        
        res.render('dashboard', {
            user: req.session.user,
            categories,
            customerCount: customerCount[0].count,
            productCount: productCount[0].count
        });
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).render('error', { error: 'Internal Server Error' });
    }
});

// Home route
app.get('/', (req, res) => {
    res.render('index', { user: req.session.user });
});

// 404 handler
app.use((req, res) => {
    res.status(404).render('error', { error: 'Page Not Found' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { error: 'Internal Server Error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});