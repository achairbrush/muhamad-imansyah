const express = require('express');
const router = express.Router();

// Simulasi database (array untuk menyimpan data user)
let users = [
    { id: 1, username: 'user1', password: 'password1', email: 'user1@example.com', name: 'John Doe', age: 25 },
    { id: 2, username: 'user2', password: 'password2', email: 'user2@example.com', name: 'Jane Smith', age: 28 }
];

// Halaman utama
router.get('/', (req, res) => {
    if (req.session.loggedin) {
        const user = users.find(u => u.username === req.session.username);
        if (user) {
            res.render('index', {
                loggedIn: true,
                username: user.username,
                name: user.name,
                age: user.age,
                email: user.email
            });
        } else {
            res.redirect('/login');
        }
    } else {
        res.render('index', { loggedIn: false });
    }
});

// Halaman login
router.get('/login', (req, res) => {
    res.render('login');
});

// Proses login
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        req.session.username = user.username;
        req.session.loggedin = true;
        res.redirect('/');
    } else {
        res.status(401).send('Username atau password salah!');
    }
});

// Halaman edit profil
router.get('/edit-profile', (req, res) => {
    if (req.session.loggedin) {
        const user = users.find(u => u.username === req.session.username);
        if (user) {
            res.render('edit-profile', {
                loggedIn: true,
                name: user.name,
                age: user.age,
                email: user.email
            });
        } else {
            res.redirect('/login');
        }
    } else {
        res.redirect('/login');
    }
});

// Proses edit profil
router.post('/edit-profile', (req, res) => {
    if (req.session.loggedin) {
        const user = users.find(u => u.username === req.session.username);
        if (user) {
            user.name = req.body.name;
            user.age = req.body.age;
            user.email = req.body.email;
            res.redirect('/');
        } else {
            res.status(500).send('Terjadi kesalahan saat mengubah biodata.');
        }
    } else {
        res.redirect('/login');
    }
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Gagal logout, coba lagi!');
        }
        res.redirect('/');
    });
});

module.exports = router;