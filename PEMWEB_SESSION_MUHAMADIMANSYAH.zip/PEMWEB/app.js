const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const router = require('./path/to/your/router'); // Ganti dengan path yang sesuai

// Middleware untuk mengurai data dari formulir
app.use(bodyParser.urlencoded({ extended: true }));

// Konfigurasi session
app.use(session({
    secret: 'your-secret-key', // Ganti dengan kunci rahasia Anda
    resave: false,
    saveUninitialized: true,
}));

// Mengatur view engine
app.set('view engine', 'ejs'); // Ganti dengan templating engine yang Anda gunakan
app.set('views', path.join(__dirname, 'views')); // Pastikan path ini benar

// Menggunakan router
app.use('/', router);

// Jalankan server
app.listen(3000, () => {
    console.log('Server berjalan di http://localhost:3000');
});